function [f_sin,sig_re,e] = EnerateSin(s,fs,y_envelope,bandsCh)
%[f_sin,sin_re] = EnerateSin(s,fs,y_envelope,bandsCh)
%   此处显示详细说明
d_200=log10(200/165.4+1)/0.06;
d_7000=log10(7000/165.4+1)/0.06;
d_space=(d_200+d_7000)/bandsCh;
fz=165.4*(10^(0.06*d_space)-1);
N=length(s);
t = (1:N)./fs;
sig_re = 0;

if     bandsCh==1
        f_sin = (200+7000)/2;
    elseif bandsCh==2
        f_sin = [(200+fz)/2;(fz+7000)/2];
    elseif bandsCh==4
        f_sin = [(200+fz)/2;(fz+2*fz)/2;(2*fz+3*fz)/2;(3*fz+7000)/2];
    elseif bandsCh==6
        f_sin = [(200+fz)/2;(fz+2*fz)/2;(2*fz+3*fz)/2;(3*fz+4*fz)/2;(4*fz+5*fz)/2;(5*fz+7000)/20];
    elseif bandsCh==8
        f_sin = [(200+fz)/2;(fz+2*fz)/2;(2*fz+3*fz)/2;(3*fz+4*fz)/2;(4*fz+5*fz)/2;(5*fz+6*fz)/2;(6*fz+7*fz)/2;(7*fz+7000)/2];
    elseif bandsCh==16
        f_sin = [(200+fz)/2;(fz+2*fz)/2;(2*fz+3*fz)/2;(3*fz+4*fz)/2;(4*fz+5*fz)/2;(5*fz+6*fz)/2;(6*fz+7*fz)/2;(7*fz+8*fz)/2;(8*fz+9*fz)/2;(9*fz+10*fz);(10*fz+11*fz)/2;(11*fz+12*fz)/2;(12*fz+13*fz)/2;(13*fz+14*fz)/2;(14*fz+15*fz)/2;(15*fz+7000)/2];
    else
        error('Unrequired number');
end
    f_sin = f_sin./(fs/2);
    
    for k=1:length(f_sin)
            e=sin(2*pi*f_sin.*t);
          %Multiply the envelope signal and sinewave
            sigi_re=e.*(y_envelope);  
          %Sum up the outputs of all bands
          sig_re = sig_re + sigi_re;
    end
    
plot(1:N,sig_re)
sound(sig_re,16000)
%figure
%plot(t,e)
%plot(1:N,sin_re)
end

