function [b1,a1] = Multbutter(order,fs,bandsCh)
%UNTITLED 此处显示有关此函数的摘要
%   fz=165.4*(10^(0.06*d)-1)
d_200=log10(200/165.4+1)/0.06;
d_7000=log10(7000/165.4+1)/0.06;



if     bandsCh==1
        Wn = [200 7000];
    elseif bandsCh==2
        d_space=(d_200+d_7000)/bandsCh;
        fz=165.4*(10^(0.06*d_space)-1);
        Wn = [200 fz;fz 7000];
    elseif bandsCh==4
        d_space=(d_200+d_7000)/bandsCh;
        fz=165.4*(10^(0.06*d_space)-1);
        Wn = [200 fz;fz 2*fz;2*fz 3*fz;3*fz 7000];
    elseif bandsCh==6
        d_space=(d_200+d_7000)/bandsCh;
        fz=165.4*(10^(0.06*d_space)-1);
        Wn = [200 fz;fz 2*fz;2*fz 3*fz;3*fz 4*fz;4*fz 5*fz;5*fz 7000];
    elseif bandsCh==8
        d_space=(d_200+d_7000)/bandsCh;
        fz=165.4*(10^(0.06*d_space)-1);
        Wn = [200 fz;fz 2*fz;2*fz 3*fz;3*fz 4*fz;4*fz 5*fz;5*fz 6*fz;6*fz 7*fz;7*fz 7000];
    elseif bandsCh==16
        d_space=(d_200+d_7000)/bandsCh;
        fz=165.4*(10^(0.06*d_space)-1);
        Wn = [200 fz;fz 2*fz;2*fz 3*fz;3*fz 4*fz;4*fz 5*fz;5*fz 6*fz;6*fz 7*fz;7*fz 8*fz;8*fz 9*fz;9*fz 10*fz;10*fz 11*fz;11*fz 12*fz;12*fz 13*fz;13*fz 14*fz;14*fz 15*fz;15*fz 7000];
    else
        error('Unrequired number');
end
    Wn = Wn/(fs/2);
    
    
for i=1:bandsCh
    
    %     Find the filter coefficients for each bandpass filter
    %     滤波器系数
    [b1,a1] = butter(order,Wn(i,:));

end

