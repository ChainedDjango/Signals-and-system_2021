function y_envelope = Envelope(b_low,a_low,y)
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明
N=length(y);
y_abs=abs(y);
y_envelope=filter(b_low,a_low,y_abs);

figure
%plot(1:N,y_envelope,'-b','linewidth',2.0),title('Envelope of y')
end

