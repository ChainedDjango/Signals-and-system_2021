function a = perfft(x,h)
N = length(x);
X = fft(x);
H = fft(h);
pa = X.*H;
a = ifft(pa);
end
