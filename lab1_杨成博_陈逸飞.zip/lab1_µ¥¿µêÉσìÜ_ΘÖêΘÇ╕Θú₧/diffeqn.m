function y=diffeqn(a,x,yn1)
%计算因果系统y[n]=ay[n-1]+x[n]的输出y[n]
%   系统是因果的
%   输入x[n],0<=n<=N-1
%   a：系数
%   x：自变量
%   yn1:初识值y[-1]，为计算y[0]
%用法：y=diffeqn(a,x,yn1)
N=length(x);
for n=1:N
    if n==1
        y(n)=a*yn1+x(n)
    else y(n)=a*y(n-1)+x(n)
    end

end

